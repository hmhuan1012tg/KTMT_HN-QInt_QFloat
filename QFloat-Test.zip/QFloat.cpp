﻿// QFloat.cpp

#include "QFloat.h"
#include "StrInt.h"

#include <string>

QFloat::QFloat(){
	m_signEx = 0;
	m_v2 = 0;
	for (short i = 0; i < 3; i++){
		m_v4[i] = 0;
	}
}

unsigned short GetBit(QFloat f, unsigned short position){
	if (position >= 112){
		return (f.m_signEx & (1 << (position - 112))) != 0;
	}
	else if (position >= 96){
		return (f.m_v2 & (1 << (position - 96))) != 0;
	}
	
	unsigned short block = position / 32;
	unsigned short i = position % 32;
	return (f.m_v4[block] & (1 << i)) != 0;
}
void SetBit(QFloat& f, unsigned short position, bool on){
	if (on){
		if (position >= 112){
			f.m_signEx |= 1 << (position - 112);
		}
		else if (position >= 96){
			f.m_v2 |= 1 << (position - 96);
		}
		else{
			unsigned short block = position / 32;
			unsigned short i = position % 32;
			f.m_v4[block] |= (1 << i);
		}
	}
	else{
		if (position >= 112){
			f.m_signEx &= ~(1 << (position - 112));
		}
		else if (position >= 96){
			f.m_v2 &= ~(1 << (position - 96));
		}
		else{
			unsigned short block = position / 32;
			unsigned short i = position % 32;
			f.m_v4[block] &= ~(1 << i);
		}
	}
}

// Dịch các bit phần trị
void ShiftRightVal(QFloat& f){
	unsigned short last = GetBit(f, 96);
	f.m_v2 >>= 1;
	for (short i = 2; i >= 0; i--){
		unsigned short next = GetBit(f, 32 * i);
		f.m_v4[i] >>= 1;
		SetBit(f, 32 * i + 31, last == 1);
		last = next;
	}
}
void ShiftLeftVal(QFloat& f){
	unsigned short first = 0;
	for (short i = 0; i < 3; i++){
		unsigned short next = GetBit(f, 32 * i + 31);
		f.m_v4[i] <<= 1;
		SetBit(f, 32 * i, first == 1);
		first = next;
	}
	f.m_v2 <<= 1;
	SetBit(f, 96, first == 1);
}

bool AllZeroSign(QFloat f){
	f.m_signEx &= ~(1 << 15);
	return f.m_signEx == 0x0000;
}
bool AllZeroVal(QFloat f){
	if (f.m_v2 != 0x0000){
		return false;
	}
	for (unsigned short i = 0; i < 3; i++){
		if (f.m_v4[i] != 0x00000000){
			return false;
		}
	}
	return true;
}

bool AllOneSign(QFloat f){
	f.m_signEx &= ~(1 << 15);
	return f.m_signEx == 0x7fff;
}
bool AllOneVal(QFloat f){
	if (f.m_v2 != 0xffff){
		return false;
	}
	for (unsigned short i = 0; i < 3; i++){
		if (f.m_v4[i] != 0xffffffff){
			return false;
		}
	}
	return true;
}

QFloat::FloatType GetFloatType(QFloat f){
	if (AllZeroSign(f)){
		if (AllZeroVal(f)){
			return QFloat::FloatType::Zero;
		}
		else{
			return QFloat::FloatType::Denormalized;
		}
	}
	if (AllOneSign(f)){
		if (AllOneVal(f)){
			return QFloat::FloatType::Infinity;
		}
		else{
			return QFloat::FloatType::NaN;
		}
	}
	return QFloat::FloatType::Normalized;
}

void PrintQFloat(QFloat f){
	StrInt *a = nullptr, *b = nullptr;

	// Kiểm tra số âm
	bool negative = GetBit(f, 127) == 1;
	
	// chuyển thành số dương so sánh mũ
	f.m_signEx &= ~(1 << 15);
	switch (GetFloatType(f)){
		case QFloat::FloatType::Zero:{
			std::cout << "0" << std::endl;
		} break;
		case QFloat::FloatType::Infinity:{
			std::cout << (negative ? "-Inf" : "Inf") << std::endl;
		} break;
		case QFloat::FloatType::NaN:{
			std::cout << "NaN" << std::endl;
		} break;
		// Số dạng không chuẩn
		case QFloat::FloatType::Denormalized:{
			b = new StrInt(0);
			// Tính phần thập phân
			unsigned short length = 0;
			while (length < 112){
				bool add = GetBit(f, length) == 1;
				*b = b->Half();
				if (add){
					b->addFirstDigit(5);
				}
				length++;
			}
			
			// x2 ^ -(2^15 - 2)
			length = 0;
			while (length < 0x3ffe){
				*b = b->Half();
				length++;
			}

			b->removeTrailingZeros();
			std::cout << (negative ? "-0." : "0.");
			std::cout << *b << std::endl;

			delete b;
		} break;
		// Dạng chuẩn
		case QFloat::FloatType::Normalized:{
			// Nếu mũ âm, ban đầu cho phần nguyên = 0, nếu ko ban đầu phần nguyên = 1
			(f.m_signEx < 0x3fff) ? a = new StrInt(0) : a = new StrInt(1);
			b = new StrInt(0);
			// Tính phần thập phân
			unsigned short length = 0;
			// Mũ âm --> chỉ tính phần thập phân
			if (f.m_signEx < 0x3fff){
				// Tính hết 112 bit phần trị
				while (length < 112){
					bool add = GetBit(f, 111 - length) == 1;
					b->addTrailingZero();
					*b = b->Half();
					if (add){
						b->addFirstDigit(5);
					}
					length++;
				}
				// Nhân thêm phần mũ âm
				length = f.m_signEx;
				// Do số dạng chuẩn -> lần chia đầu có 0.5 từ phần nguyên
				b->addTrailingZero();
				*b = b->Half();
				length++;
				while (length < 0x3fff){
					b->addTrailingZero();
					*b = b->Half();
					length++;
				}
			}
			else{ // Mũ dương
				// Tính phần nguyên
				length = 0;
				// Tính phần nguyên cho tới khi hết mũ hoặc hết bit
				while (length < 112 && length < f.m_signEx - 0x3fff){
					bool add = GetBit(f, 111 - length) == 1;
					*a = a->Double();
					if (add){
						++(*a);
					}
					length++;
				}
				// Nếu hết bit mà chưa hết mũ -> Nhân thêm cho đủ
				if (length == 112 && length < f.m_signEx - 0x3fff){
					while (length < f.m_signEx - 0x3fff){
						*a = a->Double();
						length++;
					}
				}
				// Nếu còn bit, tính phần thập phân
				else{
					length = 112 - length;
					unsigned short temp = 0;
					while (temp < length){
						bool add = GetBit(f, temp) == 1;
						b->addTrailingZero();
						*b = b->Half();
						if (add){
							b->addFirstDigit(5);
						}
						temp++;
					}
				}
			}

			a->removeLeadingZeros();
			b->removeTrailingZeros();

			std::cout << (negative ? "-" : "");
			std::cout << *a;
			if (!b->isZero()){
				std::cout << "." << *b;
			}
			std::cout << std::endl;
		} break;
	}
}
void ScanQFloat(QFloat& f){
	// Đọc vào phần nguyên và phần thập phân
	StrInt *a = nullptr, *b = nullptr;
	std::string buffer;
	std::getline(std::cin, buffer);
	if (buffer.find('.') == std::string::npos){
		a = new StrInt(buffer);
		b = new StrInt(0);
	}
	else{
		std::string temp1, temp2;
		unsigned int pos = 0;
		for (; buffer[pos] != '.'; pos++){
			temp1.push_back(buffer[pos]);
		}
		pos++;
		for (; pos < buffer.length(); pos++){
			temp2.push_back(buffer[pos]);
		}
		a = new StrInt(temp1);
		b = new StrInt(temp2);
	}

	// Nếu cả 2 = 0 -> thoát
	if (a->isZero() && b->isZero()){
		delete a, b;
		return;
	}

	// Chỉnh bit dấu
	if (a->isNegative()){
		SetBit(f, 127, true);
	}

	// Chuyển phần nguyên trước
	// Set bit đầu phần trị -> Dịch phần trị sang phải -> lặp lại
	unsigned short length = 0;
	while (!a->isZero()){
		SetBit(f, 111, !a->isEven());
		ShiftRightVal(f);
		*a = a->Half();
		length++;
	}
	// Dịch trái lại 1 lần do bị thừa 1 lần dịch phải
	ShiftLeftVal(f);

	// Lưu lại phần mũ cần cộng thêm
	unsigned short exp = length;

	// Nếu còn bit thì chuyển phần thập phân
	// Đi từ trái qua
	// Nhân 2 phần nguyên, nếu số đầu tiên >= 5 thì tạo đc số nguyên -> set bit 1
	while (length < 112 && !b->isZero()){
		bool addOne = b->firstDigit() >= 5;
		SetBit(f, 111 - length, addOne);
		*b = b->Double();
		if (addOne){
			b->removeFirstDigit();
		}
		length++;
	}

	// Tính phần mũ cần trừ đi
	// Tính tiếp phần thập phân và Dịch phần trị đến khi bit đầu phần trị = 1
	unsigned short expMinus = 0;
	while (GetBit(f, 111) == 0){
		bool addOne = b->firstDigit() >= 5;
		ShiftLeftVal(f);
		SetBit(f, 0, addOne);
		*b = b->Double();
		if (addOne){
			b->removeFirstDigit();
		}
		expMinus++;
	}

	// Tính phần mũ cuối cùng
	unsigned short expBias = 0x3fff;
	if (expMinus > exp){ // Mũ âm
		expMinus -= exp;
		if (expMinus + 1 >= expBias){ // Mũ âm vượt -> dùng số không chuẩn
			expBias = 0x0000;
		}
		else{ // Số dạng chuẩn -> Dịch trái lần nữa
			expBias -= expMinus;
			expBias--;
			ShiftLeftVal(f);
			SetBit(f, 0, b->firstDigit() >= 5);
		}
	}
	else if (exp > expMinus){ // Mũ dương
		exp -= expMinus;
		if (exp > expBias){ // Mũ dương vượt -> Infinity
			expBias = 0x7fff;
			for (unsigned short i = 0; i < 112; i++){
				SetBit(f, i, true);
			}
		}
		else{ // Số dạng chuẩn -> Dịch trái lần nữa
			expBias += exp;
			expBias--;
			ShiftLeftVal(f);
			SetBit(f, 0, b->firstDigit() >= 5);
		}
	}

	// Set phần mũ
	for (unsigned short i = 0; i < 15; i++){
		SetBit(f, 112 + i, ((1 << i) & (expBias)) != 0);
	}

	delete a, b;
}