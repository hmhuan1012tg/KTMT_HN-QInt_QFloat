﻿// StrInt.h

#pragma once

#include <string>
#include <iostream>

class StrInt{
private:
	bool m_negative;
	std::string m_numberString;

	static const unsigned int MAX_RESERVED_LENGTH = 100;

	//=========== Helper functions =========//
	StrInt divTwo(size_t length) const;

public:
	//============= Main methods ===========//
	StrInt();
	StrInt(int number);
	StrInt(const std::string& str);

	friend std::ostream& operator<<(std::ostream& os, const StrInt& number);
	friend std::istream& operator>>(std::istream& is, StrInt& number);

	unsigned short lastDigit() const;
	unsigned short firstDigit() const;

	void addFirstDigit(unsigned short num);
	void removeFirstDigit();
	
	bool isEven() const;
	bool isZero() const;
	bool isNegative() const;

	void toNegative();
	void toPositive();

	// Chia vẫn giữ 0 ở đầu ko bỏ
	StrInt Half() const;
	StrInt Double() const;

	StrInt& operator++();
	StrInt& operator--();

	void removeLeadingZeros();
	void removeTrailingZeros();

	void addTrailingZero();
};

std::istream& operator>>(std::istream& is, StrInt& number);
std::ostream& operator<<(std::ostream& os, const StrInt& number);