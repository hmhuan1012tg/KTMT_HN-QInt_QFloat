// StrInt.cpp

#include "StrInt.h"

StrInt StrInt::divTwo(size_t length) const{
	// Base case
	unsigned short lastDigit = m_numberString[length - 1] - '0';
	if (length == 1){
		return StrInt(m_negative ? -lastDigit / 2 : lastDigit / 2);
	}

	// Recursive case
	bool odd = (m_numberString[length - 2] - '0') % 2 == 1;
	StrInt number = divTwo(length - 1);

	if (odd){
		number.m_numberString.push_back(lastDigit / 2 + 5 + '0');
	}
	else{
		number.m_numberString.push_back(lastDigit / 2 + '0');
	}

	return number;
}

StrInt::StrInt() : StrInt(0){}
StrInt::StrInt(int number){
	m_numberString.reserve(MAX_RESERVED_LENGTH);

	if (number == 0){
		m_negative = false;
		m_numberString.push_back('0');
		return;
	}

	std::string temp;
	if (m_negative = number < 0 ? true : false){
		number = -number;
	}
	while (number){
		temp.push_back((number % 10) + '0');
		number /= 10;
	}
	for (int i = temp.length() - 1; i >= 0; i--)
		m_numberString.push_back(temp[i]);
}
StrInt::StrInt(const std::string& str) : m_negative(false){
	for (size_t i = 1; i < str.length(); i++){
		if (str[i] < '0' || str[i] > '9'){
			m_numberString = "0";
			return;
		}
	}

	if (str.length() < 1 || ((str[0] == '-' || str[0] == '+') && str.length() == 1)){
		m_numberString = "0";
		return;
	}

	m_negative = str[0] == '-';
	m_numberString.clear();
	for (size_t i = (str[0] == '-' || str[0] == '+') ? 1 : 0; i < str.length(); i++)
		m_numberString.push_back(str[i]);

	if (isZero()){
		m_negative = false;
	}
}

std::ostream& operator<<(std::ostream& os, const StrInt& number){
	os << (number.m_negative ? "-" : "") << number.m_numberString;

	return os;
}
std::istream& operator>>(std::istream& is, StrInt& number){
	std::string buffer;
	is >> buffer;

	number = StrInt(buffer);

	return is;
}

unsigned short StrInt::lastDigit() const{
	return m_numberString[m_numberString.length() - 1] - '0';
}
unsigned short StrInt::firstDigit() const{
	return m_numberString[0] - '0';
}

void StrInt::addFirstDigit(unsigned short num){
	m_numberString[0] += num;
}
void StrInt::removeFirstDigit(){
	m_numberString.erase(0, 1);
}

bool StrInt::isEven() const{
	return lastDigit() % 2 == 0;
}

bool StrInt::isZero() const{
	size_t firstNonZero = 0;
	while (firstNonZero < m_numberString.length() && m_numberString[firstNonZero] == '0'){
		firstNonZero++;
	}

	return firstNonZero == m_numberString.length();
}

bool StrInt::isNegative() const{
	return m_negative;
}

void StrInt::toNegative(){
	if (m_numberString != "0"){
		m_negative = true;
	}
}
void StrInt::toPositive(){
	m_negative = false;
}

StrInt StrInt::Half() const{
	return divTwo(m_numberString.length());
}
StrInt StrInt::Double() const{
	StrInt result;
	result.m_numberString.clear();

	std::string temp;
	unsigned short accumulator = 0;
	for (int i = m_numberString.length() - 1; i >= 0; i--){
		unsigned short digit = m_numberString[i] - '0';
		digit = digit * 2 + accumulator;
		accumulator = digit / 10;
		digit %= 10;
		temp.push_back(digit + '0');
	}

	if (accumulator > 0){
		temp.push_back(accumulator + '0');
	}

	for (int i = temp.length() - 1; i >= 0; i--){
		result.m_numberString.push_back(temp[i]);
	}

	result.m_negative = m_negative;

	return result;
}

StrInt& StrInt::operator++(){
	std::string temp;
	unsigned short accumulator = m_negative ? -1 : 1;
	for (int i = m_numberString.length() - 1; i >= 0; i--){
		char c = m_numberString[i] + accumulator;
		if (c < '0'){
			c = '9';
		}
		else if (c > '9'){
			c = '0';
		}
		else{
			accumulator = 0;
		}
		temp.push_back(c);
	}

	if (temp.back() == '0' && accumulator == 0){
		temp.pop_back();
	}

	m_numberString.clear();
	if (accumulator == -1){
		m_numberString.push_back('1');
		m_negative = true;
	}
	for (int i = temp.length() - 1; i >= 0; i--){
		m_numberString.push_back(temp[i]);
	}

	if (isZero()){
		m_negative = false;
	}

	return *this;
}

StrInt& StrInt::operator--(){
	std::string temp;
	unsigned short accumulator = m_negative ? 1 : -1;
	for (int i = m_numberString.length() - 1; i >= 0; i--){
		char c = m_numberString[i] + accumulator;
		if (c < '0'){
			c = '9';
		}
		else if (c > '9'){
			c = '0';
		}
		else{
			accumulator = 0;
		}
		temp.push_back(c);
	}

	if (temp.back() == '0' && accumulator == 0){
		temp.pop_back();
	}

	m_numberString.clear();
	if (accumulator == 1){
		m_numberString.push_back('1');
	}
	for (int i = temp.length() - 1; i >= 0; i--){
		m_numberString.push_back(temp[i]);
	}

	if (isZero()){
		m_negative = false;
	}

	return *this;
}

void StrInt::removeLeadingZeros(){
	size_t firstNonZero = 0;
	while (firstNonZero < m_numberString.length() && m_numberString[firstNonZero] == '0'){
		firstNonZero++;
	}

	if (firstNonZero == m_numberString.length()){
		m_numberString = "0";
	}
	else{
		std::string temp;
		for (size_t i = firstNonZero; i < m_numberString.length(); i++){
			temp.push_back(m_numberString[i]);
		}
		m_numberString = temp;
	}
}

void StrInt::removeTrailingZeros(){
	while (m_numberString.length() > 1 && m_numberString.back() == '0'){
		m_numberString.pop_back();
	}
}

void StrInt::addTrailingZero(){
	m_numberString.push_back('0');
}

