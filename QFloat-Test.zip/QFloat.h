﻿// QFloat.h

#pragma once

#include <cstdint>
#include <iostream>

struct QFloat{
public:
	uint16_t m_signEx;
	uint16_t m_v2;
	uint32_t m_v4[3];

	enum class FloatType{
		Normalized,
		Denormalized,
		Zero,
		Infinity,
		NaN,
	};
public:
	QFloat();
};

unsigned short GetBit(QFloat f, unsigned short position);
void SetBit(QFloat& f, unsigned short position, bool on);

// Dịch các bit phần trị
void ShiftRightVal(QFloat& f);
void ShiftLeftVal(QFloat& f);

bool AllZeroSign(QFloat f);
bool AllZeroVal(QFloat f);

bool AllOneSign(QFloat f);
bool AllOneVal(QFloat f);

QFloat::FloatType GetFloatType(QFloat f);

void PrintQFloat(QFloat f);
void ScanQFloat(QFloat& f);